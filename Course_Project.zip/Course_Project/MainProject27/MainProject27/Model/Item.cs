﻿namespace MainProject27.Model
{
    internal class Item
    {
        public long Identifier { get; set; }
        public string Department { get; set; }
        public int Day { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public string Model { get; set; }
        public long IMEI { get; set; }
        public int SIM { get; set; }
    }
}